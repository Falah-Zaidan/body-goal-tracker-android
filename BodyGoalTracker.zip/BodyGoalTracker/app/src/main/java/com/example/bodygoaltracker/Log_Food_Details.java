package com.example.bodygoaltracker;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;

public class Log_Food_Details extends AppCompatActivity implements AdapterView.OnItemClickListener{

    private static final int SHOW_SUBACTIVITY = 1;
    public static final String ROW_ID = "row_id" ;
    private static ArrayList<String> resultSet = new ArrayList<>();
    public static ToDoCursorAdapter todoAdapter;
    public Cursor todoCursor;
    public SQLiteDatabase db;
    private DB.MySQLOpenLiteHelper sqlOpenLiteHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log__food__details);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setTitle("Day to day breakdown");

        Log.d("TAG", "In onCreate() ");

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Log_Food_Details.this, AddItem.class);
                startActivityForResult(intent, SHOW_SUBACTIVITY);
            }
        });

        long id = -1;
        Intent intent = getIntent();
        id = intent.getLongExtra("TAG", -1);

        AddItemsToList(id);
    }


    @Override
    protected void onResume() {
        super.onResume();
    }

    public void AddItemsToList(long id){

        Log.d("TAG", "In AddItemsToList ");

        ListView listview = findViewById(R.id.listview);

        DB.MySQLOpenLiteHelper sqlOpenLiteHelper = new
                DB.MySQLOpenLiteHelper(getApplicationContext(), DB.MySQLOpenLiteHelper.DB_NAME,
                null, DB.MySQLOpenLiteHelper.DB_VERSION);

        try{
            db = sqlOpenLiteHelper.getWritableDatabase();
        }catch(SQLiteException e){
            db = sqlOpenLiteHelper.getReadableDatabase();
        }

        Log.d("TAG", "AddItemsToList: ");

        String query = "SELECT MacroTotalTable.CARBS_COLUMN, " +
                                "MacroTotalTable.fk_id, " +
                                "DateTable._id, " + //changed MacrosTable._id
                                "DateTable.DATE_COLUMN, " +
                                "MacroTotalTable.PROTEIN_COLUMN, " +
                                "MacroTotalTable.FATS_COLUMN, " +
                                "MacroTotalTable.CALORIE_COLUMN " +
                                "FROM MacroTotalTable " +
                                "INNER JOIN DateTable " +
                                "ON MacroTotalTable._id = DateTable._id";


        todoCursor = db.rawQuery(query, null);
        todoAdapter = new ToDoCursorAdapter(this, todoCursor);
        todoAdapter.changeCursor(todoCursor);

        listview.setAdapter(todoAdapter);
        listview.setOnItemClickListener(this);

    }



    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent intent = new Intent(Log_Food_Details.this, DayBreakdown.class);
        Log.d("TAG", "THE ID FROM THE ONCLICK LISTENER BEFORE INTENT: " + id);
        intent.putExtra(ROW_ID, id);
        startActivity(intent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        todoCursor.close();
        db.close();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()){
            case R.id.action_settings:
                return true;
            case R.id.action_show_items:
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }
}
