package com.example.bodygoaltracker;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Log_Progress extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log__progress);
    }
}
