package com.example.bodygoaltracker;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;

public class DB {

    public static class DBContract{

        public static final String KEY_ID =
                "_id";
        public static final String KEY_CARBS_COLUMN =
                "CARBS_COLUMN";
        public static final String KEY_PROTEIN_COLUMN =
                "PROTEIN_COLUMN";
        public static final String KEY_CALORIE_COLUMN =
                "CALORIE_COLUMN";
        public static final String KEY_FOOD_NAME_COLUMN =
                "FOOD_NAME_COLUMN";
        public static final String KEY_FATS_COLUMN =
                "FATS_COLUMN";
        public static final String KEY_DATE_COLUMN =
                "DATE_COLUMN";
        public static final String KEY_DATE_ID =
                "_id";
        public static final String KEY_ID_FK =
                "fk_id";

    }

    public static class MySQLOpenLiteHelper extends SQLiteOpenHelper {

        public static final String DB_NAME = "Macros.db";
        public static final String DATABASE_TABLE1 = "MacrosTable";
        public static final String DATABASE_TABLE2 = "DateTable";
        public static final String DATABASE_TABLE3 = "MacroTotalTable";
        public static final int DB_VERSION = 1;

        public static final String CREATE_FOOD_ITEM_TABLE =
                "create table " + DATABASE_TABLE1 +  "(" +
                DBContract.KEY_ID + " integer primary key autoincrement, " +
                DBContract.KEY_CARBS_COLUMN + " float, " +
                DBContract.KEY_PROTEIN_COLUMN + " float, " +
                DBContract.KEY_CALORIE_COLUMN + " integer, " +
                DBContract.KEY_FATS_COLUMN + " float, " +
                DBContract.KEY_FOOD_NAME_COLUMN + " text, " +
                DBContract.KEY_ID_FK + " integer, " +
                "FOREIGN KEY (fk_id) REFERENCES DateTable(_id));";

        public static final String CREATE_MACRO_TOTAL_TABLE =
                "create table " + DATABASE_TABLE3 + "(" +
                DBContract.KEY_ID + " integer primary key autoincrement, " +
                DBContract.KEY_CARBS_COLUMN + " float, " +
                DBContract.KEY_PROTEIN_COLUMN + " float, " +
                DBContract.KEY_CALORIE_COLUMN + " integer, " +
                DBContract.KEY_FATS_COLUMN + " float, " +
                DBContract.KEY_ID_FK + " integer, " +
                "FOREIGN KEY (fk_id) REFERENCES DateTable(_id));";

        public static final String CREATE_DATE_TABLE =
                "create table " + DATABASE_TABLE2 + "(" +
                 DBContract.KEY_DATE_ID + " integer primary key autoincrement, " +
                 DBContract.KEY_DATE_COLUMN + " text);";

                       // "FOREIGN KEY (Date_id) REFERENCES DateTable(Date_id)));";


        public MySQLOpenLiteHelper(@androidx.annotation.Nullable Context context, @androidx.annotation.Nullable String name, @androidx.annotation.Nullable SQLiteDatabase.CursorFactory factory, int version) {
            super(context, name, factory, version);


        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(CREATE_FOOD_ITEM_TABLE);
            db.execSQL(CREATE_DATE_TABLE);
            db.execSQL(CREATE_MACRO_TOTAL_TABLE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS " +
                    DATABASE_TABLE1);
            db.execSQL("DROP TABLE IF EXISTS " +
                    DATABASE_TABLE2);
            db.execSQL("DROP TABLE IF EXISTS " +
                    DATABASE_TABLE3);
            onCreate(db);
        }


    }

}
