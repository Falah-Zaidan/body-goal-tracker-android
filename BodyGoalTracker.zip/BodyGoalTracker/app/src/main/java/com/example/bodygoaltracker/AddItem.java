package com.example.bodygoaltracker;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;

import androidx.appcompat.app.AppCompatActivity;

import static java.lang.Float.NaN;

public class AddItem extends AppCompatActivity implements View.OnClickListener{

    public static final String STRINGS = "Strings";
    public static ArrayList<String> userInput = new ArrayList<>();
    private static int NUMBER_OF_ITEMS_ADDED;

    private TextView mDisplayDate;
    private DatePickerDialog.OnDateSetListener mDateSetListener;
    private String date;
    public static int i;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        Button b = findViewById(R.id.doneButton);
        b.setOnClickListener(this);

        mDisplayDate =
                (TextView) findViewById(R.id.setDate);

        mDisplayDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(
                         AddItem.this,
                                android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                                mDateSetListener,
                                year, month, day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });

        mDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month = month + 1;

                date = month + "/" + dayOfMonth + "/" + year;
                mDisplayDate.setText(date);
            }
        };

    }

    public void userInputIntoDatabase(){

    }

    @Override
    public void onClick(View v) {

        EditText foodItemEditText = findViewById(R.id.fooditemEditText);
        EditText proteinEditText = findViewById(R.id.proteinEditText);
        EditText fatsEditText =  findViewById(R.id.fatEditText);
        EditText carbsEditText = findViewById(R.id.carbsEditText);


        String itemName = foodItemEditText.getText().toString();
        Float carbs = Float.parseFloat(carbsEditText.getText().toString());
        Float protein = Float.parseFloat(proteinEditText.getText().toString());
        Float fats = Float.parseFloat(fatsEditText.getText().toString());

        if(itemName.isEmpty() || carbs == NaN || protein == NaN || fats == NaN )
            return;



        int calories = Math.round((carbs * 4) + (protein * 4) + (fats * 9));

        Day day = new Day(date);

        day.addItem(new Item(itemName, calories, carbs, protein, fats));

        putIntoDatabase(day);


    }

    public void putIntoDatabase(Day day){
        DB.MySQLOpenLiteHelper sqlOpenLiteHelper = new DB.MySQLOpenLiteHelper(getApplicationContext(), DB.MySQLOpenLiteHelper.DB_NAME,
                null, 1);

        SQLiteDatabase db;

        try{
            db = sqlOpenLiteHelper.getWritableDatabase();
        }catch(SQLiteException ex){
            db = sqlOpenLiteHelper.getReadableDatabase();
        }

        ContentValues cv = new ContentValues();
        ContentValues cv2 = new ContentValues();
        ContentValues cv3 = new ContentValues();

        for(Item item : day.getItems()){
            cv.put(DB.DBContract.KEY_CARBS_COLUMN, item.getCarbs());
            cv2.put(DB.DBContract.KEY_CARBS_COLUMN, item.getCarbs());
            cv.put(DB.DBContract.KEY_PROTEIN_COLUMN, item.getProtein());
            cv2.put(DB.DBContract.KEY_PROTEIN_COLUMN, item.getProtein());
            cv.put(DB.DBContract.KEY_FATS_COLUMN, item.getFats());
            cv2.put(DB.DBContract.KEY_FATS_COLUMN, item.getFats());
            cv.put(DB.DBContract.KEY_CALORIE_COLUMN, item.getCalories());
            cv2.put(DB.DBContract.KEY_CALORIE_COLUMN, item.getCalories());
            cv.put(DB.DBContract.KEY_FOOD_NAME_COLUMN, item.getItemName());
        }

        cv3.put(DB.DBContract.KEY_DATE_COLUMN, day.getDate());

        //query the DB to see what the largest foreign key value in MacrosTable is then add 1:

        String[] resultColumns = new String[]{
                DB.DBContract.KEY_ID_FK
        };

        Cursor cursor = db.rawQuery("SELECT MacrosTable.fk_id FROM MacrosTable", null);



        int highestSoFar = 0;
        int result = 0;


        while(cursor.moveToNext()) {
            result = cursor.getInt(cursor.getColumnIndexOrThrow(DB.DBContract.KEY_ID_FK));
            Log.d("TAG", "result is: " + result);
            if (result > highestSoFar) {
                highestSoFar = result;
            }
        }

        Log.d("TAG", "highestSoFar: "+ highestSoFar);
        int fkValue = highestSoFar + 1;
        Log.d("TAG", "fkValue: " + fkValue);

        cv.put(DB.DBContract.KEY_ID_FK, fkValue);
        cv2.put(DB.DBContract.KEY_ID_FK, fkValue);
       // cv3.put(DB.DBContract.KEY_DATE_ID, highestSoFar + 1);

        db.insert(DB.MySQLOpenLiteHelper.DATABASE_TABLE1, null, cv);
        db.insert(DB.MySQLOpenLiteHelper.DATABASE_TABLE3, null, cv2);
        db.insert(DB.MySQLOpenLiteHelper.DATABASE_TABLE2, null, cv3);
        cursor.close();
        db.close();

        Intent results  = new Intent(AddItem.this, Log_Food_Details.class);
        startActivity(results);

    }
}
