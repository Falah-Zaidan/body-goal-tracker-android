package com.example.bodygoaltracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.my_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Macro-nutrient tracker");


        Button logFood = (Button)findViewById(R.id.button_Log_Food);
        Button recordBw = (Button)findViewById(R.id.button_Record_BW);
        Button trackProgress = (Button)findViewById(R.id.button_Track_progress);

        logFood.setOnClickListener(this);
        recordBw.setOnClickListener(this);
        trackProgress.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button_Log_Food:
                Intent intent1 = new Intent(MainActivity.this, Log_Food_Details.class);
                startActivity(intent1);
                break;
            case R.id.button_Record_BW:
                Intent intent2 = new Intent(MainActivity.this, Log_Progress.class);
                startActivity(intent2);
                break;
            case R.id.button_Track_progress:
                Intent intent3 = new Intent(MainActivity.this, Track_progress.class);
                startActivity(intent3);
                break;
            default: break;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mainactivitymenu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()){
            case R.id.action_settings:
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
