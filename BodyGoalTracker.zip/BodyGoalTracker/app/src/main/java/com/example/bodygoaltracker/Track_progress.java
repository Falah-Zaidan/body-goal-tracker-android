package com.example.bodygoaltracker;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Track_progress extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_track_progress);
    }
}
