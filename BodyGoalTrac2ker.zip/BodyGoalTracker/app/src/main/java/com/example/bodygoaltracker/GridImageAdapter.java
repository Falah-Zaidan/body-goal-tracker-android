package com.example.bodygoaltracker;

import android.content.Context;
import android.graphics.Bitmap;
import android.media.Image;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class GridImageAdapter extends BaseAdapter {

    private static final String TAG = "GridImageAdapter";
    private Context context;
    View view;
    private LayoutInflater inflater;
    private ArrayList<String> imageNameList;
    private ArrayList<Bitmap> images;

    public GridImageAdapter(Context c, ArrayList<String> imageNameList, ArrayList<Bitmap> images){
        Log.d(TAG, "GridImageAdapter: in constructor");
        context = c;
        this.imageNameList = imageNameList;
        this.images = images;
    }

    @Override
    public int getCount() {
        return imageNameList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        Log.d(TAG, "in getView " + position);


        inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);


      //  if(convertView == null){ // what does this do, and why did removing it fix scrolling issues?
            //convertView = inflater.inflate(R.layout.row_item, null);
            view = new View(context);
            view = inflater.inflate(R.layout.row_item, null);
            TextView textView = (TextView) view.findViewById(R.id.text_view);
            ImageView imageView = (ImageView) view.findViewById(R.id.imageview);
            textView.setText(imageNameList.get(position));
            imageView.setImageBitmap(images.get(position));

       // }

        //ImageView imageView = convertView.findViewById(R.id.image_view);

        //imageView.setImageBitmap(images[position]);
        //textview.setText(imageNameList[position]);
        return view;
    }
}
