package com.example.bodygoaltracker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Calendar;

import static com.example.bodygoaltracker.Pictures_frag.getBitmapAsByteArray;

public class Take_picture extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = "TAG";
    private static final int CAMERA_REQUEST_CODE = 3;
    SQLiteDatabase db;
    TextView mDisplayDate;
    private DatePickerDialog.OnDateSetListener mDateSetListener;
    DB.MySQLOpenLiteHelper sqlOpenLiteHelper;
    String date;
    Button addPictureBtn;
    Button donePictureBtn;
    ImageView imgView;
    EditText extraInfo;
    Bitmap picture;
    private static final int VERIFY_PERMISSIONS_REQUEST = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_take_picture);

        if(checkPermissionsArray(Permissions.PERMISSIONS)){

        }else{
            verifyPermissions(Permissions.PERMISSIONS);
        }

        addPictureBtn = findViewById(R.id.addPictureBtn);
        addPictureBtn.setOnClickListener(this);

        donePictureBtn = findViewById(R.id.doneButton);
        donePictureBtn.setOnClickListener(this);

        extraInfo = findViewById(R.id.extraNotesEditText);

        setDate();
        //takePictureIntent();


    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.addPictureBtn:
                takePictureIntent();
                break;
            case R.id.doneButton:
                clickedDone();
                break;
            default: break;
        }
    }

    public void clickedDone(){

        String extraInformation = extraInfo.getText().toString();
        //Put extra information into DB?

        insertImgAndText("picture1", picture, extraInformation);
        Intent intent = new Intent(Take_picture.this, Log_Progress.class);
        intent.putExtra("Frag_Tab_Number", 1);
        startActivity(intent);

    }

    public void setDate(){

        mDisplayDate =
                (TextView) findViewById(R.id.setdatetextview);

        mDisplayDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(
                        Take_picture.this,
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        mDateSetListener,
                        year, month, day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });

        mDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month = month + 1;

                date = month + "/" + dayOfMonth + "/" + year;
                mDisplayDate.setText(date);
            }
        };

    }

    public void takePictureIntent(){
        Log.d(TAG, "onClick: launching the camera");
            if(checkPermissions(Permissions.CAMERA_PERMISSION[0])) {
                Log.d(TAG, "onClick: starting camera");
                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_REQUEST_CODE);
            }else{
                Intent intent = new Intent(getApplicationContext(), Log_Progress.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                Log.d(TAG, "failed permission");
                startActivity(intent);
            }
        }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == CAMERA_REQUEST_CODE){
            Log.d(TAG, "onActivityResult: done taking a photo");

            picture = (Bitmap)data.getExtras().get("data");
            displayImage();
        }
    }


    public void displayImage(){

        Log.d(TAG, "displayImage: in");
        //Bitmap picture = getImage("picture1");

        Bitmap picture1 = picture.createScaledBitmap(
                picture, 600, 600, false);

        imgView = findViewById(R.id.imageView);
        imgView.setImageBitmap(picture1);


        Log.d(TAG, "displayImage: finished");
    }

    public Bitmap getImage(String name){

        sqlOpenLiteHelper = new DB.MySQLOpenLiteHelper(this, DB.MySQLOpenLiteHelper.DB_NAME,
                null, 1);

        db = sqlOpenLiteHelper.getWritableDatabase();

        String qu = "SELECT i.IMAGE, i.IMAGE_NAME FROM ImagesTable i WHERE i.IMAGE_NAME=?;";
        Cursor cursor = db.rawQuery(qu, new String[]{name});

        if(cursor.moveToFirst()){
            byte[] imgByte = cursor.getBlob(0);
            cursor.close();
            return BitmapFactory.decodeByteArray(imgByte, 0, imgByte.length);
        }
        if(cursor!= null && !cursor.isClosed()){
            cursor.close();
        }

        return null;
    }

    public void insertImgAndText(String name, Bitmap image, String extraInformation){

        //TODO: query the DB to get the PK value for the same date row as imageTable then insert into that row
        //String query = "SELECT DATE_COLUMN FROM DateTable WHERE DATE_COLUMN=?;";
        //Cursor cursor = db.rawQuery(query, new String[]{name});

        sqlOpenLiteHelper = new DB.MySQLOpenLiteHelper(this, DB.MySQLOpenLiteHelper.DB_NAME,
                null, 1);

        db = sqlOpenLiteHelper.getWritableDatabase();

        byte[] data = getBitmapAsByteArray(image);

        ContentValues cv = new ContentValues();
        cv.put(DB.DBContract.KEY_IMAGE_NAME, name);
        cv.put(DB.DBContract.KEY_EXTRA_INFO_COLUMN, extraInformation);
        cv.put(DB.DBContract.KEY_DATE_COLUMN, date);
        cv.put(DB.DBContract.KEY_ID_FK, 2);
        cv.put(DB.DBContract.KEY_IMAGE, data);
        db.insert(DB.MySQLOpenLiteHelper.DATABASE_TABLE4, null, cv);

        db.close();
    }

    public boolean checkPermissions(String permission){
        Log.d(TAG, "checkPermissions: checking permission: " + permission);

        int permissionRequest = ActivityCompat.checkSelfPermission(Take_picture.this, permission);

        if(permissionRequest != PackageManager.PERMISSION_GRANTED){
            Log.d(TAG, "checkPermissions: \n Permission was not granted for: " + permission);
            return false;
        }else{
            Log.d(TAG, "checkPermissions: \n Permission was granted for: " + permission);
            return true;
        }
    }

    public boolean checkPermissionsArray(String[] permissions){
        Log.d(TAG, "checkPermissionsArray: checking permissions array.");

        for(int i=0; i< permissions.length; i++){
            String check = permissions[i];
            if(!checkPermissions(check)){
                return false;
            }
        }
        return true;
    }

    public void verifyPermissions(String[] permissions){
        Log.d(TAG, "verifyPermissions: verifying permissions");

        ActivityCompat.requestPermissions(
                Take_picture.this,
                permissions,
                VERIFY_PERMISSIONS_REQUEST
        );
    }
 }

