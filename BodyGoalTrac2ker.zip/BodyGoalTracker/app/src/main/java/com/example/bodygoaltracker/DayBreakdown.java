package com.example.bodygoaltracker;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import static java.lang.Float.NaN;

public class DayBreakdown extends AppCompatActivity implements View.OnClickListener{

    private Cursor cursor;
    private CursorAdapter2 cursorAdapter2;
    private Button btn;
    public long id;
    public SQLiteDatabase db;
    private Log_Food_Details food_details;

    @Override
    public void onClick(View v) {

        Log.d("TAG", "inOnClick: " );

        EditText fooditemEditText = findViewById(R.id.fooditemEditText);
        EditText carbsEditText = findViewById(R.id.carbsEditText);
        EditText proteinEditText = findViewById(R.id.proteinEditText);
        EditText fatsEditText = findViewById(R.id.fatEditText);

        String itemName = fooditemEditText.getText().toString();
        Float carbs = Float.parseFloat(carbsEditText.getText().toString());
        Float protein = Float.parseFloat(proteinEditText.getText().toString());
        Float fats = Float.parseFloat(fatsEditText.getText().toString());


        if(itemName.isEmpty() || carbs == NaN || protein == NaN || fats == NaN )
            return;

        int calories = Math.round((carbs * 4) + (protein * 4) + (fats * 9));

        DB.MySQLOpenLiteHelper sqlOpenLiteHelper =
                new DB.MySQLOpenLiteHelper(getApplicationContext(), DB.MySQLOpenLiteHelper.DB_NAME,
                        null, 1);
        SQLiteDatabase db;

        try{
            db = sqlOpenLiteHelper.getWritableDatabase();
        }catch(SQLiteException ex){
            db = sqlOpenLiteHelper.getReadableDatabase();
        }


        //Query the DB for current column values, then add new ones, then update the new table MacroTotal:

        String query1 = "SELECT m._id, m.PROTEIN_COLUMN, m.FATS_COLUMN, m.CALORIE_COLUMN, m.FOOD_NAME_COLUMN, m.CARBS_COLUMN, " +
                "m.fk_id, d._id, d.DATE_COLUMN " +
                "FROM MacrosTable m JOIN " +
                "DateTable d " +
                "ON m.fk_id = d._id "                                                                                                                    +
                "WHERE m.fk_id=?;";

        String[] selectionArgs = new String[]{id + ""};

        Cursor aCursor = db.rawQuery(query1, selectionArgs);

        int calories1 = 0;
        Float carbs1 = 0.0f;
        Float protein1 = 0.0f;
        Float fats1 = 0.0f;

        while(aCursor.moveToNext()){
            calories1 += aCursor.getInt(aCursor.getColumnIndexOrThrow(DB.DBContract.KEY_CALORIE_COLUMN));
            carbs1 += aCursor.getFloat(aCursor.getColumnIndexOrThrow(DB.DBContract.KEY_CARBS_COLUMN));
            protein1 += aCursor.getFloat(aCursor.getColumnIndexOrThrow(DB.DBContract.KEY_PROTEIN_COLUMN));
            fats1 += aCursor.getFloat(aCursor.getColumnIndexOrThrow(DB.DBContract.KEY_FATS_COLUMN));
        }
        aCursor.close();

        carbs1 += carbs;
        protein1 += protein;
        fats1 += fats;
        calories1 += Math.round((carbs * 4) + (protein * 4) + (fats * 9));

        ContentValues cv4 = new ContentValues();

        cv4.put(DB.DBContract.KEY_CARBS_COLUMN, carbs1);
        cv4.put(DB.DBContract.KEY_PROTEIN_COLUMN, protein1);
        cv4.put(DB.DBContract.KEY_FATS_COLUMN, fats1);
        cv4.put(DB.DBContract.KEY_CALORIE_COLUMN, calories1);
        cv4.put(DB.DBContract.KEY_ID_FK, id);

        String where = DB.DBContract.KEY_ID_FK + "=?";
        Log.d("TAG", "id: " + id);
        String[] whereArgs = {"" + id};

        db.update(DB.MySQLOpenLiteHelper.DATABASE_TABLE3, cv4, where, whereArgs);


        ContentValues cv = new ContentValues();

        cv.put(DB.DBContract.KEY_FOOD_NAME_COLUMN, itemName);
        cv.put(DB.DBContract.KEY_CARBS_COLUMN, carbs);
        cv.put(DB.DBContract.KEY_PROTEIN_COLUMN, protein);
        cv.put(DB.DBContract.KEY_FATS_COLUMN, fats);
        cv.put(DB.DBContract.KEY_CALORIE_COLUMN, calories);
        cv.put(DB.DBContract.KEY_ID_FK, id);

        db.insert(DB.MySQLOpenLiteHelper.DATABASE_TABLE1, null, cv);
        db.close();

        AddItemsToList();

        Intent intent = new Intent(DayBreakdown.this, Log_Food_Details.class);
        intent.putExtra("TAG", id);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_day_breakdown);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        ActionBar ab = getSupportActionBar();
        ab.setTitle("Day details");

        ab.setDisplayHomeAsUpEnabled(true);


        Log.d("TAG", "In DayBreakdown onCreate() ");

        Button btn = findViewById(R.id.addbtn);
        btn.setOnClickListener(this);

        Intent intent = getIntent();
        id = intent.getLongExtra(Log_Food_Details.ROW_ID, -1);

        AddItemsToList();
    }

    private void AddItemsToList(){

        RecyclerView recyclerView = findViewById(R.id.recyclerview);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        MacroBreakdownAdapter adapter = new MacroBreakdownAdapter();

        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);

        ListView listview = findViewById(R.id.listviewsofar);

        Log.d("TAG", "In AddItemsToList() DayBreakdown: ");

        DB.MySQLOpenLiteHelper sqlOpenLiteHelper =
                new DB.MySQLOpenLiteHelper(getApplicationContext(), DB.MySQLOpenLiteHelper.DB_NAME,
                        null, 1);

        try{
            db = sqlOpenLiteHelper.getWritableDatabase();
        }catch(SQLiteException ex){
            db = sqlOpenLiteHelper.getReadableDatabase();
        }

        String query1 = "SELECT m._id, m.PROTEIN_COLUMN, m.FATS_COLUMN, m.CALORIE_COLUMN, m.FOOD_NAME_COLUMN, m.CARBS_COLUMN, " +
                "m.fk_id, d._id, d.DATE_COLUMN " +
                "FROM MacrosTable m JOIN " +
                "DateTable d " +
                "ON m.fk_id = d._id " +
                "WHERE m.fk_id=?;";

        Log.d("TAG", "THIS IS THE ID VALUE FROM THE LISTVIEW CLICKLISTENER AFTER INTENT: " + id);

        String[] selectionArgs = new String[]{id + ""};

        cursor = db.rawQuery(query1, selectionArgs);

        cursorAdapter2 = new CursorAdapter2(getApplicationContext(), cursor);

        listview.setAdapter(cursorAdapter2);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        cursor.close();
        db.close();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.daybreakdownmenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()){
            case R.id.action_settings:
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
