package com.example.bodygoaltracker;


import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;


/**
 * A simple {@link Fragment} subclass.
 */
public class Bodyweight_frag extends Fragment {

    public static final String TAG = "TAG";
    ListView listview;


    public Bodyweight_frag() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_bodyweight_frag, container, false);

        /*
        Intent intent = getActivity().getIntent();
        int tabNumber = intent.getIntExtra("Frag_Tab_Number", -1);
        TabLayout tabLayout1 = getActivity().(R.id.tabs);
        tabLayout1.getTabAt(tabNumber).select();
        */

        FloatingActionButton fab = view.findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), BWInput.class);
                startActivity(intent);
            }
        });

        listview = view.findViewById(R.id.listview);
        addItemsToList();

        return view;
    }

    public void addItemsToList(){
        Log.d(TAG, "addItemsToList: ");


        DB.MySQLOpenLiteHelper sqlOpenLiteHelper =
                new DB.MySQLOpenLiteHelper(getActivity(), DB.MySQLOpenLiteHelper.DB_NAME,
                        null, 1);

        SQLiteDatabase db;

        try{
            db = sqlOpenLiteHelper.getWritableDatabase();
        }catch(SQLiteException ex){
            db = sqlOpenLiteHelper.getReadableDatabase();
        }

        String query1 = "SELECT b._id, b.BODYWEIGHT_COLUMN, b.DATE_COLUMN " +
                "FROM BodyweightTable b;";

        Cursor cursor = db.rawQuery(query1, null);
        BWCursorAdapter cursorAdapter = new BWCursorAdapter(getActivity(), cursor);

        listview.setAdapter(cursorAdapter);
    }

}
