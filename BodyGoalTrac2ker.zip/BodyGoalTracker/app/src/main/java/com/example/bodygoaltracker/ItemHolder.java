package com.example.bodygoaltracker;

import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ItemHolder extends RecyclerView.ViewHolder {

    private TextView calorieTextview;

    public ItemHolder(@NonNull View itemView) {
        super(itemView);

        calorieTextview = itemView.findViewById(R.id.calorieTextview);

    }

    public void update(final int position){

        calorieTextview.setText(position + "");

        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(itemView.getContext(), position + "", Toast.LENGTH_SHORT).show();
            }
        });
    }

}
