package com.example.bodygoaltracker;


import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class Pictures_frag extends Fragment {
    private static final String TAG = "PhotoFragment";

    //constant:
    private static final int PHOTO_FRAGMENT_NUM = 1;
    private static final int BODYWEIGHT_FRAGMENT_NUM = 2;
    private static final int CAMERA_REQUEST_CODE = 3;
    private static final int NUM_GRID_COLUMNS = 2;


    GridView gridView;
    SQLiteDatabase db;
    GridImageAdapter adapter;
    ArrayList<Bitmap> imageList = new ArrayList();
    ArrayList<String> imageNamesList = new ArrayList();

    public Pictures_frag() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_pictures_frag, container, false);

       // Button btnLaunchCamera = (Button) view.findViewById(R.id.btnLaunchCamera);
        /*btnLaunchCamera.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: launching the camera");
                if(((Log_Progress)getActivity()).getCurrentTabNumber() == PHOTO_FRAGMENT_NUM){
                    if(((Log_Progress)getActivity()).checkPermissions(Permissions.CAMERA_PERMISSION[0])) {
                        Log.d(TAG, "onClick: starting camera");
                        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        startActivityForResult(cameraIntent, CAMERA_REQUEST_CODE);
                    }else{
                        Intent intent = new Intent(getActivity(), Log_Progress.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        Log.d(TAG, "failed permission");
                        startActivity(intent);
                    }
                }
            }
        });
        */

        FloatingActionButton fab = view.findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Take_picture.class);
                startActivity(intent);
            }
        });

        //   img = view.findViewById(R.id.image);
        DB.MySQLOpenLiteHelper sqlOpenLiteHelper = new DB.MySQLOpenLiteHelper(getActivity(), DB.MySQLOpenLiteHelper.DB_NAME,
                null, 1);

        db = sqlOpenLiteHelper.getWritableDatabase();

        gridView = view.findViewById(R.id.gridview);

        return view;
    }


    /*
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == CAMERA_REQUEST_CODE){
            Log.d(TAG, "onActivityResult: done taking a photo");

            Bitmap picture = (Bitmap)data.getExtras().get("data");

            insertImg("picture1", picture);
            displayImage();
        }
    }
    */


    /*
    private void setupGridView(){
       // final ArrayList<String> imageURLs = FileSear

        int gridWidth = getResources().getDisplayMetrics().widthPixels;
        int imageWidth = gridWidth/NUM_GRID_COLUMNS;
        gridView.setColumnWidth(imageWidth);

        //GridImageAdapter adapter = new GridImageAdapter(getActivity(), R.layout.layout_grid_imageview, imgURLs, "file://");
    }
    */


    /*
    public void displayImage(){

        Log.d(TAG, "displayImage: in");
        String qu = "SELECT i.IMAGE, i.IMAGE_NAME, i.EXTRA_INFO_COLUMN, i.fk_id, i.DATE_COLUMN FROM ImagesTable i";

        //DB.MySQLOpenLiteHelper sqlOpenLiteHelper = new DB.MySQLOpenLiteHelper(getActivity(), DB);

        /*Bitmap picture1 = picture.createScaledBitmap(
                picture, 600, 600, false);


        imageList.add(picture1);
        imageNamesList.add("04/10/19");


        adapter = new GridImageAdapter(getActivity(), imageNamesList, imageList);
        gridView.setAdapter(adapter);


        Log.d(TAG, "displayImage: finished");


    }
    */


    /*
    public void insertImg(String name, Bitmap image){

        //TODO: query the DB to get the PK value for the same date row as imageTable then insert into that row

        String query = "SELECT d.DATE_COLUMN FROM DateTable d WHERE d.DATE_COLUMN=?;";
        Cursor cursor = db.rawQuery(query, new String[]{name});


        byte[] data = getBitmapAsByteArray(image);

        ContentValues cv = new ContentValues();
        cv.put(DB.DBContract.KEY_IMAGE_NAME, name);
        cv.put(DB.DBContract.KEY_IMAGE, data);
        db.insert(DB.MySQLOpenLiteHelper.DATABASE_TABLE4, null, cv);
    }
    */

    public static byte[] getBitmapAsByteArray(Bitmap bitmap){
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
        return outputStream.toByteArray();
    }

    /*
    public Bitmap getImage(String name){

        String qu = "SELECT i.IMAGE, i.IMAGE_NAME, i.EXTRA_INFO_COLUMN, i.fk_id, i.DATE_COLUMN FROM ImagesTable i";
        Cursor cursor = db.rawQuery(qu, null);

        if(cursor.moveToFirst()){
            byte[] imgByte = cursor.getBlob(0);
            cursor.close();
            return BitmapFactory.decodeByteArray(imgByte, 0, imgByte.length);
        }
        if(cursor!= null && !cursor.isClosed()){
            cursor.close();
        }

        return null;
    }
    */
}
