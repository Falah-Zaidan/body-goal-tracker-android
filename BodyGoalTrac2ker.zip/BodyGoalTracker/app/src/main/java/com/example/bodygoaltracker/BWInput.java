package com.example.bodygoaltracker;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Calendar;

public class BWInput extends AppCompatActivity implements View.OnClickListener {

    TextView mDisplayDate;
    private DatePickerDialog.OnDateSetListener mDateSetListener;
    private String date;
    EditText editText;
    DB.MySQLOpenLiteHelper sqlOpenLiteHelper;
    Float bodyweight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bwinput);

        Button doneButton = findViewById(R.id.doneButton);
        doneButton.setOnClickListener(this);

        mDisplayDate =
                (TextView) findViewById(R.id.dateTextView);

        mDisplayDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(
                        BWInput.this,
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        mDateSetListener,
                        year, month, day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });

        mDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month = month + 1;

                date = month + "/" + dayOfMonth + "/" + year;
                mDisplayDate.setText(date);
            }
        };

        editText = findViewById(R.id.inputBWEditText);
    }

    @Override
    public void onClick(View v) {

        bodyweight = Float.parseFloat(editText.getText().toString());

        sqlOpenLiteHelper = new DB.MySQLOpenLiteHelper(getApplicationContext(), DB.MySQLOpenLiteHelper.DB_NAME,
                null, 1);

        SQLiteDatabase db;


        db = sqlOpenLiteHelper.getWritableDatabase();

        ContentValues cv = new ContentValues();

        date = mDisplayDate.getText().toString();
        Log.d("TAG", "onClick: " + date);

        cv.put(DB.DBContract.KEY_BODYWEIGHT_COLUMN, bodyweight);
        cv.put(DB.DBContract.KEY_DATE_COLUMN, date);

        db.insert(DB.MySQLOpenLiteHelper.DATABASE_TABLE5, null, cv);
        db.close();

        Intent intent = new Intent(BWInput.this, Log_Progress.class);
        startActivity(intent);
    }
}
